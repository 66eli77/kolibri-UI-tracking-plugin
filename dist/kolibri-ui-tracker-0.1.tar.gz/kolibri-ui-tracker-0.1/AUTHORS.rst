
Credits
=======

Development Lead and Copyright Holder
-------------------------------------

* Learning Equality – info@learningequality.org

Community
---------

Please feel free to add your name on this list if you do a PR!

* Eli Dai (66eli77)
